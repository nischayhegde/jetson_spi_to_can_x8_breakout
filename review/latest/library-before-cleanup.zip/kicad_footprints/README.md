# BreakoutBoard component library

This bundle covers the 26 component-library inventory entries in `../componentlist.md.txt`, plus a solder bridge for selectable CAN termination and four retained former-part aliases. Several MPNs intentionally share the same package footprint and STEP file. The inventory includes original isolated-design parts; its old quantities are not a finalized BOM for the current nonisolated V1 schematic.

Updated 2026-10-18: V1 reverse-hookup protection now uses `AO3401A` (P-channel MOSFET), `BZT52C6V8-13-F` (6.8 V gate-source Zener) and one additional `RC0603FR-0710KL` (10 kohm gate pull-down). Retain `0466001.NR`, the requested 1 A fuse, and `CL10C270JB8NNNC`, the 27 pF C0G 0603 capacitor (16 per board). The former PMEG3050EP shunt diode is superseded. See the component list and `../review/mosfet_reverse_protection.txt` for wiring, 1 A load margin and circuit limitations. The live schematic is unchanged by this library update.

## Use in the existing project

Open `../breakout/breakout.kicad_pro` in KiCad 9 or newer. Add `BreakoutBoard.kicad_sym` as a **project-specific** symbol library named `BreakoutBoard`, and `BreakoutBoard.pretty` as a project-specific footprint library of the same name. Alternatively copy the supplied `sym-lib-table` and `fp-lib-table` into `../breakout/` if there are no existing tables; merge their entries if tables already exist. The supplied paths assume the existing `breakout/` project location. The live schematic and PCB were not changed.

Footprint model references use `${KIPRJMOD}/../kicad_footprints/3dmodels/*.step`. Keep this relative directory structure. For a project in the repository root, change those paths to `${KIPRJMOD}/kicad_footprints/3dmodels/` and the corresponding library-table paths.

## Files and provenance

- `BreakoutBoard.kicad_sym`: 31 standalone symbols, including part-specific aliases for passives and connectors, the termination bridge, and four former selected aliases retained for existing schematics. Parent symbols have been expanded; no external symbol inheritance is needed.
- `BreakoutBoard.pretty/`: official KiCad package footprints with local STEP references.
- `3dmodels/`: official KiCad STEP package models, shared where appropriate.
- `asset_manifest.csv` and `parts.json`: one row per purchased MPN, quantities, source symbol, footprint, STEP mapping and distributor evidence links.
- `sha256.json`: checksums for bundled selected-library assets.
- `validation/symbols/`: SVG previews exported using KiCad's symbol parser.
- `validation/report.txt`: actual KiCad footprint-loading, symbol/pad-number coverage, STEP signature and hash checks.
- `build_library.py`: reproducible extraction from the installed official KiCad 9 library distribution.
- `validate_library.py`: validation using KiCad's bundled Python / pcbnew.

**Original CAD sourcing:** At the initial CAD collection, the shell's configured network proxy refused connections. Network downloads subsequently became available for the datasheet archive. These assets were copied from the already-installed official KiCad 9 distribution at `C:/Program Files/KiCad/9.0/share/kicad`, rather than freshly downloaded from DigiKey/Mouser. Distributor CAD widgets commonly require an account or Library Loader. The result is a local library, not a collection of download links. Provenance is recorded rather than claiming supplier downloads occurred.

## Adaptations and mechanical limits

- MCP251863T-E/SS uses the official `MCP251863T-H-SS` symbol's pin arrangement and the official SSOP-28 footprint. E versus H changes temperature grade; the SS package pin mapping is shared. The bundle names and displays the selected E-grade MPN. The generator corrects the source symbol's TXD pin 23 electrical type to **input**, per Microchip Table 1-1; RXD pin 28 remains output. Existing schematic symbol caches require a deliberate library update to acquire this correction. Alias renaming preserves normal C/R reference prefixes.
- ESDONCAN1LT1G uses the KiCad NUP2105L dual bidirectional topology: lines on pins 1/2, common ground on pin 3. Its description, displayed part and datasheet link were changed. Do not infer NUP2105L electrical ratings from this graphical alias.
- TPS259530DSGR has a **locally authored** symbol from TI's TPS2595 pin table: 1=dVdt, 2=EN/UVLO, 3/4=IN, 5=OUT, 6=/FLT, 7=ILM, 8=GND, 9=grounded exposed pad. Its WSON footprint and STEP are official KiCad assets.
- TMR 6-0511 has a **locally authored** symbol from TRACO's single-output pin table: 1=-VIN, 2=+VIN, 3=REMOTE, 5=NC, 6=+VOUT, 7=-VOUT, 8=NC. The official TRACO TMR SIP footprint matches the seven populated positions on the 2.54 mm grid with position 4 omitted. The bundled STEP is a **generic TMR-family model**, not a manufacturer-certified TMR 6 model. Reserve at least the datasheet's 21.8 x 9.1 x 11.2 mm body envelope, plus tolerances and clearance, irrespective of its rendered height.
- The AND, NOT and OR parts use generic 74LS08/74LS04/74LS32 pin-compatible graphical symbols with corrected LVC part names and datasheet links, plus the official TSSOP-14 footprint and nominal STEP. Place all gate units and their separate power unit; these are CMOS LVC parts, not LS TTL components. See the BOM for the 3.3 V host-side wiring and package allocation.
- Shared IRQ adds `74AHC30PW,118`, a NAND graphical alias of 74LS30 with NC pins 9/10/13 explicitly added on the power unit. Its output feeds one spare host-side NOT stage to implement an 8-input AND after the existing eight return isolator channels. It operates from 3V3_HOST; place logic and power units. Shared-interrupt driver operation remains to be validated.
- V1 input protection retains `0466001.NR` (`Device:Fuse` / `Fuse_1206_3216Metric`) and adds `AO3401A` (`Transistor_FET:AO3401A` / `SOT-23`). MOSFET **1=G**, **2=S**, **3=D**: drain to fused input, source to protected output, gate through 10 kohm to common GND. The intrinsic diode must point from input/drain to output/source. `BZT52C6V8-13-F` uses `Device:D_Zener` / `D_SOD-123`: **1=K to Q1 source**, **2=A to Q1 gate**. Place bulk capacitance after Q1. The gate Zener does not clamp the supply rail, and this single self-biased MOSFET does not guarantee reverse-current blocking during input collapse. STEP models are nominal package geometry. The older 2 A fuse, TO-220 diode, PMEG shunt diode and 18 pF capacitor aliases are retained for existing schematic compatibility but are not current selections. Other superseded package files are retained too.
- Other STEP assets represent nominal package geometry, not manufacturer-certified individual MPN models. In particular, connector post lengths, exact molding, capacitor thickness and standoffs need mechanical review. The Harwin connector uses a generic 2x20 vertical header model.
- Solder bridges have no purchased component body, so no separate STEP model is applicable.
- The existing `SG-210STF_40.0000ML3/` directory is retained untouched. That powered oscillator is not selected for this BOM.

## Attribution

Derived symbols, footprints and package models: [KiCad official libraries](https://www.kicad.org/libraries/). See the [KiCad library license and exception](https://www.kicad.org/libraries/license/) for redistribution terms. Original library authors retain their attribution. Changes here are MPN aliases, flattened symbol inheritance, locally authored symbols identified above, and model paths rewritten to local STEP files.

Validation proves file parsing, presence and pin-number coverage. It does not replace a schematic review, pad-dimension review, isolation-clearance review, or prototype electrical/mechanical validation.
